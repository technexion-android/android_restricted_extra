
#!/bin/bash -ex
# This script is used to fetch the complete source for android build

echo "Start fetching the source for android build"

if [ -z "$WORKSPACE" ];then
    WORKSPACE=$PWD
    echo "Setting WORKSPACE to $WORKSPACE"
fi

if [ -z "$android_builddir" ];then
    android_builddir=$WORKSPACE/android_build
    echo "Setting android_builddir to $android_builddir"
fi

if [ ! -d "$android_builddir" ]; then
    # Create android build dir if it does not exist.
    mkdir $android_builddir
    cd $android_builddir
    repo init -u https://source.codeaurora.org/external/imx/imx-manifest.git -b imx-android-oreo -m imx-o8.0.0_1.0.0_ga.xml
      rc=$?
      if [ "$rc" != 0 ]; then
         echo "---------------------------------------------------"
         echo "-----Repo Init failure"
         echo "---------------------------------------------------"
         return 1
      fi
fi

# Don't Delete .repo directory and hidden files
#rm -rf $android_builddir/.??*
cd $android_builddir

repo sync
      rc=$?
      if [ "$rc" != 0 ]; then
         echo "---------------------------------------------------"
         echo "------Repo sync failure"
         echo "---------------------------------------------------"
         return 1
      fi

# Copy all the proprietary packages to the android build folder

cd $WORKSPACE/imx-o8.0.0_1.0.0_ga
cp -r vendor/nxp $android_builddir/vendor
cp -r EULA.txt $android_builddir
cp -r SCR* $android_builddir

cd $android_builddir

# unset variables

unset android_builddir
unset WORKSPACE

echo "Android source is ready for the build"
